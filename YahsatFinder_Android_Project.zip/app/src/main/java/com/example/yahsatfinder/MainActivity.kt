package com.example.yahsatfinder

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.*
import android.hardware.*
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.view.View
import android.widget.*
import android.view.Gravity
import android.graphics.Color
import kotlin.math.*

class MainActivity : Activity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var azimuthNow = 0f
    private var targetAzimuth = 0.0
    private var targetElevation = 0.0
    private var currentLat = 32.65
    private var currentLon = 51.67
    private lateinit var compassView: CompassView
    private lateinit var info: TextView
    private lateinit var arrowView: ArrowView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        buildUi()
        requestPermissions(arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ), 22)
        updateCalculation()
        getLocation()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 26, 20, 20)
            setBackgroundColor(Color.rgb(8, 22, 42))
        }
        val title = TextView(this).apply {
            text = "راهنمای تنظیم دیش یاه‌ست"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 14)
        }
        val subtitle = TextView(this).apply {
            text = "Yahsat 1A • موقعیت مداری 52.5° شرقی"
            textSize = 15f
            setTextColor(Color.rgb(120, 205, 255))
            gravity = Gravity.CENTER
        }
        info = TextView(this).apply {
            textSize = 17f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(8, 12, 8, 12)
        }
        compassView = CompassView(this)
        arrowView = ArrowView(this)
        val refresh = Button(this).apply {
            text = "به‌روزرسانی موقعیت و زاویه‌ها"
            setOnClickListener { getLocation(); updateCalculation() }
        }
        val note = TextView(this).apply {
            text = "نکته: فلش، جهت هدف را نسبت به بالای گوشی نشان می‌دهد. گوشی را افقی نگه دارید و قطب‌نما را دور از فلز و آهنربا کالیبره کنید. زاویه‌ها تقریبی‌اند؛ کیفیت نهایی را با رسیور بررسی کنید."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(4, 10, 4, 8)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(info)
        root.addView(compassView, LinearLayout.LayoutParams(-1, 0, 2f))
        root.addView(arrowView, LinearLayout.LayoutParams(-1, 0, 1.4f))
        root.addView(refresh)
        root.addView(note)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)?.also {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        } ?: run {
            sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION)?.also {
                sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        val rotation = FloatArray(9)
        val orientation = FloatArray(3)
        if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(rotation, event.values)
            SensorManager.getOrientation(rotation, orientation)
            azimuthNow = (Math.toDegrees(orientation[0].toDouble()).toFloat() + 360f) % 360f
        } else if (event.sensor.type == Sensor.TYPE_ORIENTATION) {
            azimuthNow = (event.values[0] + 360f) % 360f
        }
        compassView.invalidate()
        arrowView.invalidate()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun getLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return
        }
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (last != null) {
                currentLat = last.latitude
                currentLon = last.longitude
                updateCalculation()
            }
            val provider = if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER
            lm.requestSingleUpdate(provider, object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    currentLat = location.latitude
                    currentLon = location.longitude
                    updateCalculation()
                }
                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }, mainLooper)
        } catch (_: Exception) { }
    }

    private fun updateCalculation() {
        val result = calculate(currentLat, currentLon, 52.5)
        targetAzimuth = result.first
        targetElevation = result.second
        info.text = "موقعیت: %.4f° ، %.4f°\nجهت افقی از شمال حقیقی: %.1f°\nارتفاع دیش: %.1f°\nجهت فعلی گوشی: %.1f°".format(
            currentLat, currentLon, targetAzimuth, targetElevation, azimuthNow
        )
        compassView.invalidate()
        arrowView.invalidate()
    }

    // Azimuth is clockwise from true north. Elevation uses a spherical Earth approximation.
    private fun calculate(latDeg: Double, lonDeg: Double, satLonDeg: Double): Pair<Double, Double> {
        val lat = Math.toRadians(latDeg)
        val delta = Math.toRadians(satLonDeg - lonDeg)
        val az = (Math.toDegrees(atan2(sin(delta), -sin(lat) * cos(delta))) + 360.0) % 360.0
        val cosPsi = cos(lat) * cos(delta)
        val el = Math.toDegrees(atan2(cosPsi - 0.1512, sqrt(max(0.0, 1.0 - cosPsi * cosPsi))))
        return Pair(az, el)
    }

    inner class CompassView(context: Context) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            val r = min(width, height) * 0.38f
            p.style = Paint.Style.STROKE
            p.strokeWidth = 4f
            p.color = Color.rgb(55, 155, 230)
            canvas.drawCircle(cx, cy, r, p)
            p.strokeWidth = 1.5f
            for (i in 0 until 36) {
                val a = Math.toRadians((i * 10 - 90).toDouble())
                val inner = if (i % 3 == 0) r - 18 else r - 9
                canvas.drawLine(cx + cos(a).toFloat()*inner, cy + sin(a).toFloat()*inner,
                    cx + cos(a).toFloat()*r, cy + sin(a).toFloat()*r, p)
            }
            p.style = Paint.Style.FILL
            p.color = Color.WHITE
            p.textSize = 30f
            canvas.drawText("N", cx - 10, cy - r - 12, p)
            canvas.drawText("S", cx - 10, cy + r + 38, p)
            canvas.drawText("W", cx - r - 38, cy + 10, p)
            canvas.drawText("E", cx + r + 18, cy + 10, p)
            val diff = ((targetAzimuth - azimuthNow + 540.0) % 360.0 - 180.0).toFloat()
            canvas.save()
            canvas.rotate(diff, cx, cy)
            p.color = Color.rgb(40, 230, 130)
            val path = Path().apply {
                moveTo(cx, cy - r + 20)
                lineTo(cx - 17, cy - r + 58)
                lineTo(cx + 17, cy - r + 58)
                close()
            }
            canvas.drawPath(path, p)
            canvas.restore()
            p.color = Color.WHITE
            p.textSize = 18f
            canvas.drawText("فلش سبز = جهت هدف", cx - 80, cy + 8, p)
        }
    }

    inner class ArrowView(context: Context) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            val diff = ((targetAzimuth - azimuthNow + 540.0) % 360.0 - 180.0).toFloat()
            p.color = Color.rgb(40, 230, 130)
            p.strokeWidth = 12f
            p.strokeCap = Paint.Cap.ROUND
            canvas.save()
            canvas.rotate(diff, cx, cy)
            canvas.drawLine(cx, cy + 50, cx, cy - 65, p)
            val path = Path().apply {
                moveTo(cx, cy - 90); lineTo(cx - 25, cy - 50); lineTo(cx + 25, cy - 50); close()
            }
            p.style = Paint.Style.FILL
            canvas.drawPath(path, p)
            canvas.restore()
            p.color = Color.WHITE
            p.textSize = 18f
            canvas.drawText("جهت هدف نسبت به گوشی: %.0f°".format(diff), 12f, height - 12f, p)
        }
    }
}
